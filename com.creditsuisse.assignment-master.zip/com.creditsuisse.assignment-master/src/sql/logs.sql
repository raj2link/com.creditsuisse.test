create table if not exists
    Serverlogs(event_id varchar(45), event_duration int(5),
     event_type varchar(40), event_host varchar (40))